import 'dart:ffi';
import 'dart:io';
import 'package:ffi/ffi.dart';

final DynamicLibrary nativeLib = Platform.isAndroid
    ? DynamicLibrary.open("libsort.so")
    : throw UnsupportedError("Only Android is supported");

typedef SortFunc = Void Function(Pointer<Int32>, Int32, Pointer<Int32>);
typedef Sort = void Function(Pointer<Int32>, int, Pointer<Int32>);

final Sort bubbleSort = nativeLib
    .lookup<NativeFunction<SortFunc>>('bubble_sort')
    .asFunction();

final Sort mergeSort = nativeLib
    .lookup<NativeFunction<SortFunc>>('merge_sort')
    .asFunction();

Future<Map<String, dynamic>> runSort(List<int> array, bool isBubble) async {
  final ptr = calloc<Int32>(array.length);
  final steps = calloc<Int32>();
  for (int i = 0; i < array.length; i++) ptr[i] = array[i];

  if (isBubble) bubbleSort(ptr, array.length, steps);
  else mergeSort(ptr, array.length, steps);

  final sorted = List.generate(array.length, (i) => ptr[i]);
  final count = steps.value;
  calloc.free(ptr);
  calloc.free(steps);

  return {"sorted": sorted, "steps": count};
}
