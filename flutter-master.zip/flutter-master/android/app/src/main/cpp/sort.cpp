#include <stdint.h>
#include <time.h>

extern "C" {

int32_t get_time_ms() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int32_t)(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

int32_t bubble_sort(int32_t* arr, int32_t len, int32_t* steps) {
    *steps = 0;
    int32_t start = get_time_ms();

    for (int32_t i = 0; i < len - 1; i++) {
        for (int32_t j = 0; j < len - i - 1; j++) {
            (*steps)++;
            if (arr[j] > arr[j + 1]) {
                int32_t temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    int32_t end = get_time_ms();
    return end - start;
}

void merge(int32_t* arr, int32_t l, int32_t m, int32_t r, int32_t* steps) {
    int32_t n1 = m - l + 1;
    int32_t n2 = r - m;
    int32_t L[500], R[500];

    for (int32_t i = 0; i < n1; i++) L[i] = arr[l + i];
    for (int32_t j = 0; j < n2; j++) R[j] = arr[m + 1 + j];

    int32_t i = 0, j = 0, k = l;
    while (i < n1 && j < n2) {
        (*steps)++;
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
}

void merge_sort_recursive(int32_t* arr, int32_t l, int32_t r, int32_t* steps) {
    if (l < r) {
        int32_t m = (l + r) / 2;
        merge_sort_recursive(arr, l, m, steps);
        merge_sort_recursive(arr, m + 1, r, steps);
        merge(arr, l, m, r, steps);
    }
}

int32_t merge_sort(int32_t* arr, int32_t len, int32_t* steps) {
    *steps = 0;
    int32_t start = get_time_ms();

    merge_sort_recursive(arr, 0, len - 1, steps);

    int32_t end = get_time_ms();
    return end - start;
}

}
